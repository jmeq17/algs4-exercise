public class CircularSuffixArray {
    private final int[] index;
    private final int n;

    // circular suffix array of s
    public CircularSuffixArray(String s) {
        if (s == null) throw new IllegalArgumentException();

        n = s.length();
        index = new int[n];
        for (int i = 0; i < n; i++) index[i] = i;

        MSD.sort(s, index);
    }

    // length of s
    public int length() {
        return n;
    }

    // returns index of ith sorted suffix
    public int index(int i) {
        if (i < 0 || i >= n) throw new IllegalArgumentException();
        return index[i];
    }
}
