import edu.princeton.cs.algs4.BinaryStdIn;
import edu.princeton.cs.algs4.BinaryStdOut;

public class MoveToFront {
    private static final int R = 256;

    // apply move-to-front encoding, reading from standard input and writing to standard output
    public static void encode() {
        int[] mtf = new int[R];
        for (int i = 0; i < R; i++) mtf[i] = i;

        while (!BinaryStdIn.isEmpty()) {
            char current = BinaryStdIn.readChar();
            int index = mtf[current];
            BinaryStdOut.write(index, 8);

            int count = 0;

            for (int i = 0; count < index; i++) {
                if (mtf[i] < index) {
                    mtf[i]++;
                    count++;
                }
            }
            mtf[current] = 0;
        }
        BinaryStdOut.close();
    }

    // apply move-to-front decoding, reading from standard input and writing to standard output
    public static void decode() {
        char[] mtf = new char[R];
        for (int i = 0; i < R; i++) mtf[i] = (char) i;

        while (!BinaryStdIn.isEmpty()) {
            int i = BinaryStdIn.readChar();
            BinaryStdOut.write(mtf[i], 8);

            char tem = mtf[i];

            System.arraycopy(mtf, 0, mtf, 1, i);

            mtf[0] = tem;
        }
        BinaryStdOut.close();
    }

    // if args[0] is "-", apply move-to-front encoding
    // if args[0] is "+", apply move-to-front decoding
    public static void main(String[] args) {
        if (args[0].equals("-")) encode();
        if (args[0].equals("+")) decode();
    }
}
